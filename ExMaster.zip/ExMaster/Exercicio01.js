const min = fuction (n1, n2){
    return n1 <= n2 ? n1 : n2;
}
console.log(min(0, 10));
console.log(min(0, -10));
console.log(min(5, 7));
console.log(min(9, -1));
console.log(min(3, 1));
console.log(min(4, 4));